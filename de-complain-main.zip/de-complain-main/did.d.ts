declare module '*.did' {
    const content: string;
    export default content;
  }
  